module.exports=[26758,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},38872,a=>{"use strict";let b={src:a.i(26758).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=app_b9b1292a._.js.map
var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_04d884c6.js")
R.c("server/chunks/_next-internal_server_app_api_generate_route_actions_5bfe9259.js")
R.m(6713)
module.exports=R.m(6713).exports

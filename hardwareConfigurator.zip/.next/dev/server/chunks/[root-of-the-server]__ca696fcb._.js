module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/rules.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deriveBaselineSpec",
    ()=>deriveBaselineSpec
]);
const USAGE_PRESETS = {
    office: {
        cpu: "Intel Core i5 14500T / AMD Ryzen 5 Pro 8650HS",
        gpu: "Integrated Intel UHD 770 / Radeon 780M",
        ram: "16 GB DDR5",
        storage: "512 GB NVMe PCIe Gen4 SSD",
        networking: "Dual-band Wi-Fi 6E, 1x RJ45 2.5GbE",
        display: "14-15.6\" FHD IPS, low blue-light"
    },
    web: {
        cpu: "Intel Core i5 13500H / Ryzen 5 7640U",
        gpu: "Integrated Intel Iris Xe",
        ram: "16 GB DDR5",
        storage: "512 GB NVMe SSD",
        networking: "Wi-Fi 6E, 1x RJ45",
        display: "13-15\" FHD IPS"
    },
    editing: {
        cpu: "Intel Core i7 14700K / Ryzen 9 7900",
        gpu: "NVIDIA RTX 4060 / RTX A2000",
        ram: "32 GB DDR5",
        storage: "1 TB NVMe + 2 TB SATA SSD",
        networking: "Wi-Fi 7, Dual 2.5GbE",
        display: "27\" QHD wide-gamut (external)"
    },
    rendering: {
        cpu: "AMD Threadripper Pro 7965WX / Intel Xeon W-2400",
        gpu: "NVIDIA RTX 5000 Ada / RTX 4500",
        ram: "64 GB DDR5 ECC",
        storage: "2 TB NVMe Gen4 + 4 TB NVMe scratch",
        networking: "Dual 10GbE, Wi-Fi 7",
        display: "Dual 27\" 4K HDR"
    },
    coding: {
        cpu: "Intel Core Ultra 7 165H / Ryzen 7 Pro 8845HS",
        gpu: "Integrated Intel Arc / Radeon 780M",
        ram: "32 GB LPDDR5x",
        storage: "1 TB NVMe SSD",
        networking: "Wi-Fi 7, 1x RJ45 (dock)",
        display: "14-16\" 2.5K 120Hz"
    },
    "data analysis": {
        cpu: "Intel Xeon Gold 5515+ / AMD EPYC 8324P",
        gpu: "NVIDIA L40S / Tesla T4 (depends on budget)",
        ram: "64 GB DDR5 ECC",
        storage: "2 TB NVMe + 4 TB NVMe scratch + 8 TB HDD",
        networking: "Dual 10GbE, optional Fibre Channel",
        display: "Rack/remote console"
    },
    gaming: {
        cpu: "Intel Core i7 14700KF / Ryzen 7 7800X3D",
        gpu: "NVIDIA RTX 4070 Super / Radeon RX 7900 GRE",
        ram: "32 GB DDR5 6000MHz",
        storage: "1 TB NVMe + 2 TB NVMe",
        networking: "Wi-Fi 7, 2.5GbE",
        display: "27\" 1440p 165Hz"
    },
    server: {
        cpu: "Dual Intel Xeon Silver 4514Y+ / Dual AMD EPYC 9334",
        gpu: "Optional NVIDIA L4 (virtualization)",
        ram: "128 GB DDR5 ECC (expandable)",
        storage: "4x 1.92 TB NVMe U.2 + 8x 4 TB SAS",
        networking: "4x 10GbE SFP+ + OCP 3.0 slot",
        display: "Remote (iDRAC/ILO)"
    },
    mixed: {
        cpu: "Intel Core i7 14700 / Ryzen 9 7900",
        gpu: "NVIDIA RTX 4060 Ti",
        ram: "32 GB DDR5",
        storage: "1 TB NVMe + 2 TB SATA SSD",
        networking: "Wi-Fi 6E, 2.5GbE",
        display: "24\" QHD IPS"
    }
};
const PERFORMANCE_NOTES = {
    cpu: "Prioritize higher-core-count CPUs and sustained boost clocks.",
    gpu: "Allocate more budget toward discrete GPUs with ample VRAM.",
    ram: "Ensure higher capacity (>=32 GB) and faster DDR5 modules.",
    balanced: "Distribute budget across CPU, GPU, and memory for all-rounder builds."
};
const QUANTITY_NOTES = {
    "1": "Single-unit procurement—focus on best possible fit.",
    "5-20": "Small batch—standard warranty uplift and imaging support.",
    "20-50": "Department rollout—consider vendor-managed inventory.",
    "50-200": "Campus/site refresh—negotiate volume discounts and staging.",
    "200+": "Enterprise-wide deployment—engage OEM bid teams and logistic SLAs."
};
const deriveBaselineSpec = (requirements)=>{
    const preset = USAGE_PRESETS[requirements.usageType];
    const accessories = [];
    if (requirements.formFactor === "laptop" || requirements.formFactor === "ultrabook") {
        accessories.push("USB-C dock with RJ45 + DP/HDMI");
    }
    if (requirements.quantity !== "1") {
        accessories.push("Imaging + asset tagging kit");
    }
    if (requirements.networkingNeeds) {
        accessories.push(`Networking add-ons: ${requirements.networkingNeeds}`);
    }
    const estimatedUnitPrice = (()=>{
        switch(requirements.usageType){
            case "office":
            case "web":
                return "$800 - $1,100";
            case "coding":
            case "mixed":
                return "$1,300 - $1,700";
            case "editing":
            case "gaming":
                return "$1,800 - $2,400";
            case "rendering":
            case "data analysis":
                return "$4,000 - $6,500";
            case "server":
                return "$6,000+";
            default:
                return "Request quote";
        }
    })();
    const notes = [
        PERFORMANCE_NOTES[requirements.performancePriority],
        QUANTITY_NOTES[requirements.quantity]
    ];
    if (requirements.durabilityNeeds) {
        notes.push(`Durability: ${requirements.durabilityNeeds}`);
    }
    if (requirements.warrantyPreferences) {
        notes.push(`Warranty: ${requirements.warrantyPreferences}`);
    }
    if (requirements.powerPreferences) {
        notes.push(`Power targets: ${requirements.powerPreferences}`);
    }
    if (requirements.complianceNotes) {
        notes.push(`Compliance: ${requirements.complianceNotes}`);
    }
    return {
        ...preset,
        storage: requirements.storageRequirements || preset.storage,
        networking: requirements.networkingNeeds || preset.networking,
        accessories,
        recommendedVendors: requirements.brandConstraints.trim().length > 0 ? requirements.brandConstraints.split(",").map((item)=>item.trim()) : [
            "Dell",
            "HP",
            "Lenovo"
        ],
        estimatedUnitPrice,
        notes
    };
};
}),
"[project]/lib/openrouter.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getOpenRouterSummary",
    ()=>getOpenRouterSummary
]);
const OPENROUTER_COMPLETIONS_URL = "https://openrouter.ai/api/v1/chat/completions";
const DEFAULT_MODEL = "tngtech/deepseek-r1t2-chimera:free";
const getOpenRouterSummary = async (requirements)=>{
    if (!process.env.OPENROUTER_API_KEY) {
        throw new Error("OPENROUTER_API_KEY is not configured");
    }
    const response = await fetch(OPENROUTER_COMPLETIONS_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
            "HTTP-Referer": "https://hardwareconfigurator.local",
            "X-Title": "Hardware Configurator"
        },
        body: JSON.stringify({
            model: DEFAULT_MODEL,
            // Increased tokens for more detailed responses
            max_tokens: 1000,
            messages: [
                {
                    role: "system",
                    content: "return strict JSON with snake_case keys exactly as follows: {\"best_fit_configuration\": string (component breakdown), \"price_estimate\": string (price per component), \"unit_price\": string (single unit price in USD like \"$1,250.00\"), \"total_price\": string (total for all units in USD like \"$25,000.00\"), \"reasoning\": string (brief explanation why each component fits the use case), \"bulk_scaling\": string (short notes on bulk procurement)}."
                },
                {
                    role: "user",
                    content: JSON.stringify({
                        requirements,
                        instructions: "based on the requirements sent return strict json"
                    })
                }
            ],
            temperature: 0.4
        })
    });
    if (!response.ok) {
        const errorPayload = await response.text();
        throw new Error(`OpenRouter request failed: ${response.status} ${errorPayload}`);
    }
    const payload = await response.json();
    // Log the raw JSON payload returned from OpenRouter for debugging
    try {
    // payload received (not logged)
    } catch (e) {
    // payload non-serializable (not logged)
    }
    const message = payload?.choices?.[0]?.message;
    const rawContent = message?.content;
    const text = typeof rawContent === "string" ? rawContent : rawContent !== undefined ? JSON.stringify(rawContent) : "";
    // Additional granular logs removed
    // Normalize the text by removing surrounding markdown code fences if present
    const cleanResponseText = (input)=>{
        const t = input?.trim();
        if (!t) return "";
        // If the response is wrapped in a fenced code block like ```json\n{...}\n```
        if (t.startsWith("```")) {
            // Remove the leading fence and optional language tag
            const withoutLeading = t.replace(/^```[a-zA-Z]*\n?/, "");
            // Remove the trailing fence if present
            const withoutTrailing = withoutLeading.replace(/\n?```$/, "");
            return withoutTrailing.trim();
        }
        return t;
    };
    const cleanedText = cleanResponseText(text);
    // Cleaned text available in `cleanedText`
    try {
        const parsed = JSON.parse(cleanedText);
        // Parsed JSON available in `parsed`
        return {
            bestFitConfiguration: parsed.best_fit_configuration || "",
            priceEstimate: parsed.price_estimate || "",
            unitPrice: parsed.unit_price || parsed.price_estimate || "Price on request",
            totalPrice: parsed.total_price || "Price on request",
            reasoning: parsed.reasoning || "",
            bulkScaling: parsed.bulk_scaling || ""
        };
    } catch (error) {
        throw new Error(`Unable to parse OpenRouter response as JSON. Raw content: ${text}. Error: ${String(error)}`);
    }
};
}),
"[project]/app/api/generate/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$rules$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/rules.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$openrouter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/openrouter.ts [app-route] (ecmascript)");
;
;
;
const REQUIRED_FIELDS = [
    "usageType",
    "budgetRange",
    "quantity",
    "formFactor",
    "requiredSoftware",
    "brandConstraints",
    "performancePriority"
];
const normalizeBody = (body)=>{
    if (!body || typeof body !== "object") {
        throw new Error("Invalid request payload");
    }
    const source = body;
    const normalized = {
        usageType: source.usageType,
        budgetRange: String(source.budgetRange ?? ""),
        quantity: source.quantity,
        formFactor: source.formFactor,
        requiredSoftware: Array.isArray(source.requiredSoftware) ? source.requiredSoftware : typeof source.requiredSoftware === "string" && source.requiredSoftware.length > 0 ? source.requiredSoftware.split(",").map((item)=>item.trim()) : [],
        brandConstraints: String(source.brandConstraints ?? ""),
        performancePriority: source.performancePriority,
        storageRequirements: String(source.storageRequirements ?? ""),
        networkingNeeds: String(source.networkingNeeds ?? ""),
        durabilityNeeds: String(source.durabilityNeeds ?? ""),
        warrantyPreferences: String(source.warrantyPreferences ?? ""),
        powerPreferences: String(source.powerPreferences ?? ""),
        complianceNotes: String(source.complianceNotes ?? "")
    };
    return normalized;
};
async function POST(request) {
    try {
        const body = await request.json();
        const normalized = normalizeBody(body);
        for (const field of REQUIRED_FIELDS){
            if (normalized[field] === undefined || normalized[field] === null || typeof normalized[field] === "string" && normalized[field].trim().length === 0 || Array.isArray(normalized[field]) && normalized[field].length === 0) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    error: `Missing required field: ${String(field)}`
                }, {
                    status: 400
                });
            }
        }
        // Try AI first - if it works, use it exclusively
        let aiSummary = null;
        let baselineSpec = null;
        let useBaselineFallback = false;
        try {
            aiSummary = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$openrouter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getOpenRouterSummary"])(normalized);
        // AI succeeded - we'll use AI-only approach
        } catch (error) {
            console.error("OpenRouter summary failed, falling back to baseline spec", error);
            // AI failed - fall back to baseline spec
            useBaselineFallback = true;
            baselineSpec = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$rules$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deriveBaselineSpec"])(normalized);
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            requirements: normalized,
            baselineSpec: baselineSpec || null,
            aiSummary,
            useBaselineFallback,
            generatedAt: new Date().toISOString()
        });
    } catch (error) {
        console.error("Configuration generation failed", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Unable to process request",
            details: String(error)
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ca696fcb._.js.map
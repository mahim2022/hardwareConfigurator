var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/route.js")
R.c("server/chunks/node_modules_next_f8d10175._.js")
R.c("server/chunks/[root-of-the-server]__ca696fcb._.js")
R.c("server/chunks/_next-internal_server_app_api_generate_route_actions_5bfe9259.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/generate/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/generate/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_xlsx_xlsx_mjs_dc88e2e2._.js",
  "static/chunks/_01b91977._.js"
],
    source: "dynamic"
});
